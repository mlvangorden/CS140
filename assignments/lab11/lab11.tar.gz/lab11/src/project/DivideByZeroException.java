package project;

public class DivideByZeroException extends RuntimeException{
	public DivideByZeroException(String msg){
		super(msg);
	}
}