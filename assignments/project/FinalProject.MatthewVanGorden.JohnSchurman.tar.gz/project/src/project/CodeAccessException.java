package project;

public class CodeAccessException extends RuntimeException {
	public CodeAccessException(String msg){
		super(msg);
	}
}
