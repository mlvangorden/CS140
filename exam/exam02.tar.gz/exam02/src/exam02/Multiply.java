package exam02;

public class Multiply implements BinaryFunction {
	
	@Override
	public int apply(int a, int b) {
		return a*b;
	}
}
