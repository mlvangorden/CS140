package exam02;

public class Summer {
	private double[] array;
	
	public Summer(double[] array) {
		this.array = array;
	}
	
	public double measure() {
		double retVal = 0;
		for(double el : array) {
			retVal += el;
		}
		return retVal;
	}
	
	public int value() {
		return array.length;
	}
}
