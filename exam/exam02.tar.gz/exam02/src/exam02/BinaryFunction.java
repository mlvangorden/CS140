package exam02;

public interface BinaryFunction {
	int apply(int a, int b);
}
